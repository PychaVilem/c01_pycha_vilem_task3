package render;

import solids.Solid;

public class Renderer {

    public void render(Solid solid){
        // TODO: naprogramovat
        // - mám vb a ib
        // - procházím ib, podle indexu si vezmu 2 vrcholy z vb
        // - spojím se úsečkou
    }

}

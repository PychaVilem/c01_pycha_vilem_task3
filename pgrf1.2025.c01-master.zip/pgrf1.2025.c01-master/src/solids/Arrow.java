package solids;

import transforms.Point3D;

public class Arrow extends Solid {

    public Arrow() {
        // TODO: naplním VB - v souřadnicích rasteru
        vertexBuffer.add(new Point3D());
        // TODO: naplním IB
    }
}

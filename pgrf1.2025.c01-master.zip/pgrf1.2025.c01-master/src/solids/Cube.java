package solids;

public class Cube extends Solid {

}
